<?php
/*
Plugin Name: Interactive Service Tree
Description: A plugin that provides an interactive tree view of services.
Version: 1.0
Author: Piyush Agarwal
License: GPLv2 or later
License URI: https://www.gnu.org/licenses/gpl-2.0.html
*/

add_action('wp_enqueue_scripts', 'ist_enqueue_assets');
function ist_enqueue_assets() {
    wp_enqueue_style('ist-style', plugin_dir_url(__FILE__) . 'css/style.css');
    wp_enqueue_script('jquery');
    wp_enqueue_script('ist-script', plugin_dir_url(__FILE__) . 'js/script.js', ['jquery'], null, true);

    // AJAX support
    wp_localize_script('ist-script', 'ist_ajax_obj', [
    'ajax_url' => admin_url('admin-ajax.php'),
    'nonce'    => wp_create_nonce('ist_service_nonce'),
    ]);
}


// Register Custom Post Type: Service

function ist_register_service_post_type() {
    $labels = [
        'name'               => 'Services',
        'singular_name'      => 'Service',
        'menu_name'          => 'Services',
        'name_admin_bar'     => 'Service',
        'add_new'            => 'Add New',
        'add_new_item'       => 'Add New Service',
        'new_item'           => 'New Service',
        'edit_item'          => 'Edit Service',
        'view_item'          => 'View Service',
        'all_items'          => 'All Services',
        'search_items'       => 'Search Services',
        'parent_item_colon'  => 'Parent Service:',
        'not_found'          => 'No services found.',
        'not_found_in_trash' => 'No services found in Trash.',
    ];

    $args = [
        'labels'             => $labels,
        'public'             => true,
        'has_archive'        => false,
        'hierarchical'       => true,  // Allows parent-child structure
        'show_in_menu'       => true,
        'supports'           => ['title', 'editor', 'thumbnail', 'page-attributes'],  // Add Page Attributes support
        'show_in_rest'       => true,  // Ensure compatibility with the block editor
        'menu_position'      => 20,
        'menu_icon'          => 'dashicons-hammer',
        'editor'             => 'block',  // Enable block editor
    ];

    register_post_type('ist_service', $args);
}
add_action('init', 'ist_register_service_post_type');


add_shortcode('interactive_services', 'ist_display_service_tree');
function ist_display_service_tree() {
    ob_start();
    ?>
    <div class="services-container">
        <h2>Our Services</h2>
        <ul id="service-tree">
            <?php
            $parents = get_posts([
                'post_type' => 'ist_service',
                'numberposts' => -1,
                'post_parent' => 0,
                'orderby' => 'menu_order',
                'order' => 'ASC',
            ]);

            foreach ($parents as $parent) {
                echo '<li>';
                echo '<a href="#" class="toggle-service"><i class="expand-icon">+</i> ' . esc_html($parent->post_title) . '</a>';

                $children = get_posts([
                    'post_type' => 'ist_service',
                    'numberposts' => -1,
                    'post_parent' => $parent->ID,
                    'orderby' => 'menu_order',
                    'order' => 'ASC',
                ]);

                if (!empty($children)) {
                    echo '<ul class="sub-service">';
                    foreach ($children as $child) {
                    echo '<li><a href="#" class="service-item" data-service-id="' . esc_attr($child->ID) . '">' . esc_html($child->post_title) . '</a></li>';

                    }
                    echo '</ul>';
                }

                echo '</li>';
            }
            ?>
        </ul>
    </div>

    <!-- Modal remains the same -->
    <div id="service-modal" class="modal-overlay" style="display:none;">
        <div class="modal-box">
            <span id="close-modal" class="modal-close">&times;</span>
            <div id="service-detail-content"></div>
        </div>
    </div>

    <?php
    return ob_get_clean();
}


// AJAX Handler
add_action('wp_ajax_load_service_details', 'ist_load_service_details');
add_action('wp_ajax_nopriv_load_service_details', 'ist_load_service_details');

function ist_load_service_details() {
    // Check nonce for security
    if ( ! isset($_POST['nonce']) ) {
    wp_send_json_error('Nonce missing');
    wp_die();
}

$nonce = sanitize_text_field( wp_unslash( $_POST['nonce'] ) );

if ( ! wp_verify_nonce( $nonce, 'ist_service_nonce' ) ) {
    wp_send_json_error('Invalid nonce');
    wp_die();
}


    $id = isset($_POST['service_id']) ? intval($_POST['service_id']) : 0;
    $post = get_post($id);

    if ( $post && $post->post_type === 'ist_service' ) {
        $content = '<h3>' . esc_html($post->post_title) . '</h3>';
        $content .= '<div>' . wp_kses_post(apply_filters('the_content', $post->post_content)) . '</div>';

        wp_send_json_success($content);
    } else {
        wp_send_json_error('Service not found.');
    }

    wp_die();
}


