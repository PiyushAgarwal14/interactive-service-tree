=== Interactive Service Tree ===
Contributors: Piyush Agarwal
Author URI: https://github.com/PiyushAgarwal14
Tags: service, modal, accordion, custom post type
Requires at least: 5.6
Tested up to: 6.8
Requires PHP: 7.0
Stable tag: 1.0
License: GPLv2 or later
License URI: https://www.gnu.org/licenses/gpl-2.0.html


== Plugin Homepage ==

https://github.com/PiyushAgarwal14/interactive-service-tree


== Description ==

This plugin displays an expandable list of services in a tree format with modal details when clicked. It allows creating a hierarchical structure of services using WordPress custom post types. Perfect for showing detailed information about services in a professional and interactive way.

== Installation ==

1. Upload the plugin files to the `/wp-content/plugins/interactive-service-tree/` directory, or install the plugin through the WordPress plugins screen directly.
2. Activate the plugin through the 'Plugins' screen in WordPress.
3. Use the `[interactive_services]` shortcode to display the services tree on any page or post.

== Usage ==

1. Go to **Services > Add New** to create a new service.
2. Add the title and content for the service.
3. To create child services, go to **Services > Add New**, enter a title (e.g., "Child Service 1"), and in the right sidebar **Parent** option click on none and a modal diaplay with input box from there you can select parent.
4. Publish the service.
5. On the front-end, the services will appear as an expandable tree, and clicking on a service will open a modal with detailed information.

== Changelog ==

= 1.0 =
* Initial release with functionality to create a service tree with modals.
* Allows adding parent and child services with modal popup for each service.

== Frequently Asked Questions ==

= How do I add child services? =

When creating a service, you can set a parent for the service under the sidebar at right-hand side of the editor. Click on parent option none, which will open a modal with input field, Select an existing service as the parent, and the service will appear as a child under that parent in the front-end tree.

= Can I modify the style of the modal? =

Yes! You can modify the CSS in the plugin's `style.css` file or override it in your theme's custom CSS settings.

== Screenshots ==

1. Screenshot 1: A tree view of services (with parent and child services).
   Screenshot Url: https://raw.githubusercontent.com/PiyushAgarwal14/wp-plugin/refs/heads/main/Screenshot1.png
2. Screenshot 2: Modal showing service details when clicked.
   Screenshot Url:  https://raw.githubusercontent.com/PiyushAgarwal14/wp-plugin/refs/heads/main/Screenshot2.png

== Upgrade Notice ==

= 1.0 =
Initial release.
