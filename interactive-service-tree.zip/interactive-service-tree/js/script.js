jQuery(document).ready(function($) {

    // Toggle service categories
    $(document).on('click', '.toggle-service', function(e) {
        e.preventDefault();
        const parent = $(this).parent();
        const icon = $(this).find('.expand-icon');
        parent.toggleClass('active');
        icon.text(icon.text() === '+' ? '-' : '+');
    });

    // Open modal and prevent scroll
    $(document).on('click', '.service-item', function(e) {
        e.preventDefault();
        const serviceId = $(this).data('service-id');

        $.ajax({
    url: ist_ajax_obj.ajax_url,
    type: 'POST',
    data: {
        action: 'load_service_details',
        service_id: serviceId,
        nonce: ist_ajax_obj.nonce
    },
    success: function(response) {
        if (response.success) {
            $('#service-detail-content').html(response.data);
            $('#service-modal').fadeIn();
            $('body').addClass('modal-open');
        } else {
            alert(response.data || 'Failed to load service details.');
        }
    },
    error: function() {
        alert('Failed to load service details.');
    }
});

    });

    // Close modal on close icon
    $(document).on('click', '#close-modal', function() {
        $('#service-modal').fadeOut();
        $('body').removeClass('modal-open'); // restore scroll
    });

    // Close modal when clicking outside modal-box
    $(window).on('click', function(e) {
        if ($(e.target).is('#service-modal')) {
            $('#service-modal').fadeOut();
            $('body').removeClass('modal-open'); // restore scroll
        }
    });

});
